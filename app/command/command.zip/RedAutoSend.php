<?php

namespace app\command;

use app\model\LotteryJoinModel;
use app\service\BotJieLongRedEnvelopeService;
use think\console\Command;
use think\console\Input;
use think\console\Output;

class RedAutoSend extends BaseCommand
{
    /**
     * 红包自动发送。扫描红包发送，如果有没发送的，及时发送出去
     * @return void
     */
    protected function configure()
    {
        // 指令配置
        $this->setName('redautosend')
            ->setDescription('the redautosend command');
    }

    protected function execute(Input $input, Output $output)
    {
        //查询是否有没发送出去的红包
        $list = LotteryJoinModel::getInstance()->getCacheCreateInfoList();

        if (empty($list)){
            $output->writeln('redautosend end null');
            return ;
        }

        //操作发送
        foreach ($list as $key=>$value){
            if ($value['lottery_type'] == LotteryJoinModel::RED_TYPE_FL || $value['lottery_type'] == LotteryJoinModel::RED_TYPE_DX){
                BotJieLongRedEnvelopeService::getInstance()->setSend($value['id']);
            }

            if ($value['lottery_type'] == LotteryJoinModel::RED_TYPE_JL){
                BotJieLongRedEnvelopeService::getInstance()->setSend($value['id']);
            }
        }

        $output->writeln('redautosend end');
    }
}